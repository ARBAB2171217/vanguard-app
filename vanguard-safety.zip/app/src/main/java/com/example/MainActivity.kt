package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.*
import com.example.ui.screens.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() // Mandatory Edge-to-Edge support

        setContent {
            MyApplicationTheme {
                val modelState: VanguardViewModel = viewModel()
                VanguardSafetyRouter(viewModel = modelState)
            }
        }
    }
}

@Composable
fun VanguardSafetyRouter(viewModel: VanguardViewModel) {
    val flowState by viewModel.appFlowState.collectAsStateWithLifecycle()

    // Slide and Crossfade transition routers based on flow states
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        when (flowState) {
            is AppFlow.Splash -> {
                SplashScreen(
                    onSplashFinished = { viewModel.appFlowState.value = AppFlow.Onboarding }
                )
            }
            is AppFlow.Onboarding -> {
                OnboardingScreen(
                    onOnboardingFinished = { viewModel.appFlowState.value = AppFlow.MainDashboard }
                )
            }
            is AppFlow.MainDashboard -> {
                VanguardMainDashboard(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun VanguardMainDashboard(viewModel: VanguardViewModel) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val members by viewModel.members.collectAsStateWithLifecycle()
    val geofences by viewModel.geofences.collectAsStateWithLifecycle()
    val selectedMember by viewModel.selectedMember.collectAsStateWithLifecycle()
    val alerts by viewModel.alerts.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()

    val aiResponseText by viewModel.aiResponseText.collectAsStateWithLifecycle()
    val aiIsLoading by viewModel.aiIsLoading.collectAsStateWithLifecycle()
    val chatbotInput by viewModel.chatbotInput.collectAsStateWithLifecycle()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = ObsidianBg,
        topBar = {
            // Sophisticated Dark Header layout
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Custom 'SF' Initials Avatar circle
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(PrimaryNeonCyan) // soft lavender
                            .padding(2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "SF",
                            color = Color(0xFF381E72), // Contrast purple-focused color from HTML spec
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    
                    Column {
                        Text(
                            text = "Smith Residence",
                            color = TextPrimaryLight,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(SecondaryActiveGreen, CircleShape)
                            )
                            Text(
                                text = "4 LIVE PROTECTORS",
                                color = PrimaryNeonCyan,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }

                // Bell icon notification indicator button
                IconButton(
                    onClick = { /* Could toggle system notification logs if requested */ },
                    modifier = Modifier
                        .size(44.dp)
                        .background(SurfaceMidnight, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications bell indicator",
                        tint = TextPrimaryLight
                    )
                }
            }
        },
        bottomBar = {
            // High fidelity bottom console navigation bar strictly following Material Design 3 guidelines
            NavigationBar(
                containerColor = SurfaceMidnight,
                tonalElevation = 8.dp,
                windowInsets = WindowInsets.navigationBars
            ) {
                // Tactical Map Panel Option
                NavigationBarItem(
                    selected = activeTab == "map",
                    onClick = { viewModel.activeTab.value = "map" },
                    label = { Text("Radar Map", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.LocationOn, contentDescription = "Satellite radar map tracker") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = PrimaryNeonCyan,
                        indicatorColor = PrimaryNeonCyan,
                        unselectedIconColor = TextSecondaryMuted,
                        unselectedTextColor = TextSecondaryMuted
                    ),
                    modifier = Modifier.testTag("nav_item_map")
                )

                // Stealth SOS Option
                NavigationBarItem(
                    selected = activeTab == "sos",
                    onClick = { viewModel.activeTab.value = "sos" },
                    label = { Text("Panic SOS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Warning, contentDescription = "Active emergency alarm trigger") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = AlertCriticalRed,
                        indicatorColor = AlertCriticalRed,
                        unselectedIconColor = TextSecondaryMuted,
                        unselectedTextColor = TextSecondaryMuted
                    ),
                    modifier = Modifier.testTag("nav_item_sos")
                )

                // Guardian AI Insights Option
                NavigationBarItem(
                    selected = activeTab == "ai",
                    onClick = { viewModel.activeTab.value = "ai" },
                    label = { Text("Guardia AI", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Star, contentDescription = "Automated AI assessments copilot") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = PrimaryNeonCyan,
                        indicatorColor = PrimaryNeonCyan,
                        unselectedIconColor = TextSecondaryMuted,
                        unselectedTextColor = TextSecondaryMuted
                    ),
                    modifier = Modifier.testTag("nav_item_ai")
                )

                // Encrypted Safety Chats Option
                NavigationBarItem(
                    selected = activeTab == "chat",
                    onClick = { viewModel.activeTab.value = "chat" },
                    label = { Text("Secure Chat", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Send, contentDescription = "End-to-End security chats") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = PrimaryNeonCyan,
                        indicatorColor = PrimaryNeonCyan,
                        unselectedIconColor = TextSecondaryMuted,
                        unselectedTextColor = TextSecondaryMuted
                    ),
                    modifier = Modifier.testTag("nav_item_chat")
                )

                // Family Config Options
                NavigationBarItem(
                    selected = activeTab == "family",
                    onClick = { viewModel.activeTab.value = "family" },
                    label = { Text("Config", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Settings, contentDescription = "Family circle coordinates adjustments") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = PrimaryNeonCyan,
                        indicatorColor = PrimaryNeonCyan,
                        unselectedIconColor = TextSecondaryMuted,
                        unselectedTextColor = TextSecondaryMuted
                    ),
                    modifier = Modifier.testTag("nav_item_family")
                )

                // Admin Monitoring Panel Option (Enterprise Control HUD!)
                NavigationBarItem(
                    selected = activeTab == "admin",
                    onClick = { viewModel.activeTab.value = "admin" },
                    label = { Text("Monitoring", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    icon = { Icon(imageVector = Icons.Default.Build, contentDescription = "Tactical network monitors") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBg,
                        selectedTextColor = AccentMutedGold,
                        indicatorColor = AccentMutedGold,
                        unselectedIconColor = TextSecondaryMuted,
                        unselectedTextColor = TextSecondaryMuted
                    ),
                    modifier = Modifier.testTag("nav_item_admin")
                )
            }
        }
    ) { innerPadding ->
        // Direct container body rendering according to chosen navigation state
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(ObsidianBg)
        ) {
            when (activeTab) {
                "map" -> LiveMapPanel(
                    viewModel = viewModel,
                    members = members,
                    geofences = geofences,
                    selectedMember = selectedMember,
                    alerts = alerts
                )
                "sos" -> SOSPanel(
                    viewModel = viewModel,
                    alerts = alerts
                )
                "ai" -> AIPanel(
                    viewModel = viewModel,
                    aiResponse = aiResponseText,
                    isLoading = aiIsLoading,
                    chatInput = chatbotInput
                )
                "chat" -> ChatPanel(
                    viewModel = viewModel,
                    messages = messages
                )
                "family" -> FamilyHubPanel(
                    viewModel = viewModel,
                    geofences = geofences
                )
                "admin" -> AdminConsolePanel(
                    viewModel = viewModel,
                    alerts = alerts,
                    members = members
                )
            }
        }
    }
}
