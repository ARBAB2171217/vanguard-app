package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Theme Colors
val ObsidianBg = Color(0xFF1C1B1F)       // Warm Charcoal Background
val SurfaceMidnight = Color(0xFF2B2930)  // Warm Dark Gray Secondary Surface
val PrimaryNeonCyan = Color(0xFFD0BCFF)  // Soft Elegant M3 Lavender Accent
val SecondaryActiveGreen = Color(0xFF34D399) // Soft Emerald Active Status
val AlertCriticalRed = Color(0xFFF2B8B5) // Soft Coral Pink Emergency Red/Coral
val AccentMutedGold = Color(0xFFFFD166)  // Muted Amber/Gold Highlights

val TextPrimaryLight = Color(0xFFE6E1E5) // M3 Off-white readable text
val TextSecondaryMuted = Color(0xFF938F99) // Lavender-tinted slate gray descriptive text

// Map Canvas / Inner Deep Dark Slate Card Background
val MapCanvasBg = Color(0xFF0F172A)      // Deep Dark Slate Blue
val SosTextOnCoral = Color(0xFF601410)   // Dark Burgundy text for Coral SOS Button

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFF938F99)
val Pink80 = Color(0xFFF2B8B5)

val Purple40 = Color(0xFF2B2930)
val PurpleGrey40 = Color(0xFF938F99)
val Pink40 = Color(0xFF1C1B1F)
