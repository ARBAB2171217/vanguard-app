package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = PrimaryNeonCyan,
    secondary = SecondaryActiveGreen,
    tertiary = AccentMutedGold,
    background = ObsidianBg,
    surface = SurfaceMidnight,
    error = AlertCriticalRed,
    onPrimary = ObsidianBg,
    onSecondary = ObsidianBg,
    onTertiary = ObsidianBg,
    onBackground = TextPrimaryLight,
    onSurface = TextPrimaryLight,
    onError = TextPrimaryLight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Premium Dark Mode for military terminal feel
    dynamicColor: Boolean = false, // Use our handcrafted design colors
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
