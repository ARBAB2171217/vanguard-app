package com.example.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiClient
import com.example.data.database.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class VanguardViewModel(application: Application) : AndroidViewModel(application) {

    private val database = VanguardDatabase.getDatabase(application)
    private val repository = VanguardRepository(database.vanguardDao())

    // --- Core Navigation States ---
    val appFlowState = MutableStateFlow<AppFlow>(AppFlow.Splash) // Splash -> Onboarding -> MainDashboard
    val activeTab = MutableStateFlow("map") // map, sos, ai, chat, family, admin

    // --- Local Persistence Feeds ---
    val members: StateFlow<List<MemberEntity>> = repository.allMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val geofences: StateFlow<List<GeofenceEntity>> = repository.allGeofences
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<AlertEntity>> = repository.allAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val messages: StateFlow<List<MessageEntity>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Interactive State Triggers ---
    val selectedMember = MutableStateFlow<MemberEntity?>(null)
    val shakeCountSimulated = MutableStateFlow(0)
    val sosTimerActive = MutableStateFlow(false)
    val sosCountdown = MutableStateFlow(5)

    // --- Guardian AI Copilot States ---
    val aiResponseText = MutableStateFlow("Tap 'Run Perimeter Checkup' or chat with Guardian AI to analyze live family movements.")
    val aiIsLoading = MutableStateFlow(false)
    val chatbotInput = MutableStateFlow("")

    // Running tracking background coroutine task
    private var trackingSimulatorJob: Job? = null

    init {
        viewModelScope.launch {
            // Instantly seeds localized default safety tables on first initial launch
            repository.seedInitialDataIfEmpty()
            // Pull first active member to focus profile on setup
            members.first { it.isNotEmpty() }.let {
                selectedMember.value = it.firstOrNull()
            }
        }
        // Spawn active GPS coordinate simulator thread to trigger live movement matching Life360 features
        startTrackingTelemetrySimulator()
    }

    private fun startTrackingTelemetrySimulator() {
        trackingSimulatorJob?.cancel()
        trackingSimulatorJob = viewModelScope.launch {
            while (true) {
                delay(4000) // Poll real-time database-backed tracker drift every 4 seconds
                if (appFlowState.value == AppFlow.MainDashboard) {
                    repository.simulateLiveMovementUpdates()
                    // Keep selected member stats updated
                    selectedMember.value?.let { current ->
                        val updated = database.vanguardDao().getMemberById(current.id)
                        if (updated != null) {
                            selectedMember.value = updated
                        }
                    }
                }
            }
        }
    }

    // Interactive member profiling focusing the tactical camera
    fun focusMember(member: MemberEntity) {
        selectedMember.value = member
    }

    // Spawns clean automated geofence perimeters on map touch
    fun addNewGeofence(name: String, type: String, radius: Double) {
        viewModelScope.launch {
            val centerLat = selectedMember.value?.latitude ?: 37.7749
            val centerLng = selectedMember.value?.longitude ?: -122.4194
            val newFence = GeofenceEntity(
                id = java.util.UUID.randomUUID().toString(),
                name = name,
                zoneType = type.uppercase(),
                centerLat = centerLat,
                centerLng = centerLng,
                radiusMeters = radius,
                isTriggered = false
            )
            repository.insertGeofence(newFence)
            
            // Log immediate perimeter deployment
            repository.insertAlert(
                AlertEntity(
                    id = java.util.UUID.randomUUID().toString(),
                    title = "New Perimeter Deployed",
                    description = "Custom geo-perimeter '$name' active (${radius.toInt()}m bounds).",
                    timestamp = System.currentTimeMillis(),
                    severity = "INFO"
                )
            )
        }
    }

    fun deleteGeofence(id: String) {
        viewModelScope.launch {
            repository.deleteGeofence(id)
        }
    }

    // One-Tap Stealth Panic System
    fun triggerSOSBroadcast() {
        viewModelScope.launch {
            val activeName = selectedMember.value?.name ?: "You"
            repository.triggerSOSAlert("$activeName activated the Stealth SOS Trigger. Coordinates verified. Audio/Camera streaming initiated.")
            
            val activeMsg = MessageEntity(
                id = java.util.UUID.randomUUID().toString(),
                senderId = "me_1",
                senderName = "You",
                text = "⚠️ CRITICAL SOS TRIGGERED! Safe connection active.",
                timestamp = System.currentTimeMillis(),
                isMine = true
            )
            repository.insertMessage(activeMsg)
        }
    }

    // Send E2EE Family Safety messages
    fun sendSafetyMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val systemMsg = MessageEntity(
                id = java.util.UUID.randomUUID().toString(),
                senderId = "me_1",
                senderName = "You",
                text = text,
                timestamp = System.currentTimeMillis(),
                isMine = true
            )
            repository.insertMessage(systemMsg)

            // Simulate immediate family reply for rich interactive UX
            delay(1500)
            val responder = members.value.randomOrNull()?.name ?: "Sarah"
            val responseMsg = MessageEntity(
                id = java.util.UUID.randomUUID().toString(),
                senderId = "responder_1",
                senderName = responder,
                text = "Received safety check! Safe at our end.",
                timestamp = System.currentTimeMillis(),
                isMine = false
            )
            repository.insertMessage(responseMsg)
        }
    }

    // Guardian AI generative prompt calling the Gemini API Client
    fun runGuardiaPerimeterCheckup() {
        viewModelScope.launch {
            aiIsLoading.value = true
            aiResponseText.value = "Analyzing live family historical telemetry, geofence barriers, and terminal device battery status..."
            
            // Build raw telemetry context parameters strictly conforming to prompt rules
            val activeFamily = members.value.joinToString("\n") { m ->
                "- ${m.name} (${m.relationship}): Lat: ${m.latitude}, Lng: ${m.longitude}, Battery: ${m.batteryPercent}%, Speed: ${m.speedKmh} km/h, Status: '${m.statusMessage}'"
            }
            val activeFences = geofences.value.joinToString("\n") { f ->
                "- ${f.name} (${f.zoneType}): Center Lat: ${f.centerLat}, Lng: ${f.centerLng}, Radius: ${f.radiusMeters}m"
            }

            val systemInsightPrompt = """
                Family circles telemetry logs state:
                $activeFamily
                
                Active spatial geofences are defined as:
                $activeFences
                
                Please generate a thorough corporate security analysis outlining the 'Family Safety Score', 'Travel Risk Index', details of any anomalies (e.g. low batteries, fast speeds, paths deviances), and immediate checklists for family group action!
            """.trimIndent()

            val responseText = GeminiClient.getSafetyAssessment(systemInsightPrompt)
            aiResponseText.value = responseText
            aiIsLoading.value = false
        }
    }

    fun submitAIChatbotQuery() {
        val query = chatbotInput.value
        if (query.isBlank()) return
        chatbotInput.value = ""

        viewModelScope.launch {
            aiIsLoading.value = true
            aiResponseText.value = "Consulting Guardian AI satellite safety servers for prompt guide..."
            
            val responseText = GeminiClient.getSafetyAssessment(query)
            aiResponseText.value = responseText
            aiIsLoading.value = false
        }
    }

    fun clearSystemLogs() {
        viewModelScope.launch {
            repository.clearAlerts()
        }
    }

    override fun onCleared() {
        super.onCleared()
        trackingSimulatorJob?.cancel()
    }
}

// Immutable sealed class matching Splash/Onboarding app flow
sealed class AppFlow {
    object Splash : AppFlow()
    object Onboarding : AppFlow()
    object MainDashboard : AppFlow()
}
