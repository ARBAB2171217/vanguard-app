package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.data.database.GeofenceEntity
import com.example.data.database.MemberEntity
import com.example.ui.theme.*
import kotlin.math.sqrt

@Composable
fun CustomInteractiveMap(
    members: List<MemberEntity>,
    geofences: List<GeofenceEntity>,
    selectedMember: MemberEntity?,
    onMemberSelected: (MemberEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    // Spatial panning offsets
    var panOffsetX by remember { mutableStateOf(0f) }
    var panOffsetY by remember { mutableStateOf(0f) }
    var scaleFactor by remember { mutableStateOf(1.2f) }

    // Center on the selected member if clicked from profile lists
    LaunchedEffect(selectedMember) {
        if (selectedMember != null) {
            // Map lat/lng coordinates mapped to relative canvas offsets
            // Base lat: 37.7600, Base lng: -122.4200
            val relativeLat = (selectedMember.latitude - 37.7600f) * 12000f
            val relativeLng = (selectedMember.longitude - -122.4200f) * 12000f
            panOffsetX = -relativeLng.toFloat()
            panOffsetY = relativeLat.toFloat()
            scaleFactor = 1.4f
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MapCanvasBg)
            .pointerInput(Unit) {
                // Detects dragging to pan the tactical map
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    panOffsetX += dragAmount.x
                    panOffsetY += dragAmount.y
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val centerX = canvasWidth / 2f
            val centerY = canvasHeight / 2f

            // Layered graphics transformation matching scale, offsets and focus coordinates
            withTransform({
                translate(centerX + panOffsetX, centerY + panOffsetY)
                scale(scaleFactor, scaleFactor)
            }) {

                // 1. Draw Grid Lines (Sophisticated Dark Grid Materialized)
                val gridSpacing = 120f
                val gridBound = 3000f
                for (x in -25..25) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.1f),
                        start = Offset(x * gridSpacing, -gridBound),
                        end = Offset(x * gridSpacing, gridBound),
                        strokeWidth = 1f
                    )
                }
                for (y in -25..25) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.1f),
                        start = Offset(-gridBound, y * gridSpacing),
                        end = Offset(gridBound, y * gridSpacing),
                        strokeWidth = 1f
                    )
                }

                // 2. Draw Topography (Water Reservoir, Highways & Rivers)
                // Draw a beautiful cyber river path
                val waterPath = Path().apply {
                    moveTo(-1500f, -800f)
                    cubicTo(-800f, -600f, -200f, -1200f, 400f, -800f)
                    cubicTo(1000f, -400f, 1500f, -1000f, 2000f, -900f)
                }
                drawPath(
                    path = waterPath,
                    color = Color(0xFF1B365D).copy(alpha = 0.5f),
                    style = Stroke(width = 80f, cap = StrokeCap.Round)
                )

                // Beautiful neon roads (Cyber Highway Network grid)
                val roadLines = listOf(
                    Pair(Offset(-1200f, -300f), Offset(1500f, -300f)),
                    Pair(Offset(-400f, -1200f), Offset(-400f, 1000f)),
                    Pair(Offset(300f, -1000f), Offset(300f, 1200f)),
                    Pair(Offset(-1000f, 400f), Offset(1500f, 400f)),
                )
                for (road in roadLines) {
                    drawLine(
                        color = Color(0xFF1E293B),
                        start = road.first,
                        end = road.second,
                        strokeWidth = 12f
                    )
                    drawLine(
                        color = Color(0xFF334155).copy(alpha = 0.5f),
                        start = road.first,
                        end = road.second,
                        strokeWidth = 2f
                    )
                }

                // 3. Render Geofence Zones (Radial translucent custom color bubbles)
                for (fence in geofences) {
                    val rLat = (fence.centerLat - 37.7600) * 12000f
                    val rLng = (fence.centerLng - -122.4200) * 12000f
                    val fenceOffset = Offset(rLng.toFloat(), -rLat.toFloat())
                    val radiusPx = fence.radiusMeters.toFloat() * 1.5f

                    val (zoneColor, strokeColor) = when (fence.zoneType) {
                        "HOME" -> Pair(SecondaryActiveGreen.copy(alpha = 0.12f), SecondaryActiveGreen.copy(alpha = 0.4f))
                        "SCHOOL" -> Pair(PrimaryNeonCyan.copy(alpha = 0.12f), PrimaryNeonCyan.copy(alpha = 0.4f))
                        "DANGER" -> Pair(AlertCriticalRed.copy(alpha = 0.15f), AlertCriticalRed.copy(alpha = 0.6f))
                        else -> Pair(AccentMutedGold.copy(alpha = 0.12f), AccentMutedGold.copy(alpha = 0.4f))
                    }

                    // Translucent danger zone filling
                    drawCircle(
                        color = zoneColor,
                        center = fenceOffset,
                        radius = radiusPx
                    )
                    drawCircle(
                        color = strokeColor,
                        center = fenceOffset,
                        radius = radiusPx,
                        style = Stroke(width = 2.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f))
                    )

                    // Draw fence tag name
                    val textPaint = android.graphics.Paint().apply {
                        color = when (fence.zoneType) {
                            "DANGER" -> 0xFFF2B8B5.toInt()
                            "HOME" -> 0xFF34D399.toInt()
                            else -> 0xFFD0BCFF.toInt()
                        }
                        textSize = 24f
                        isAntiAlias = true
                        textAlign = android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
                    }
                    drawContext.canvas.nativeCanvas.drawText(
                        fence.name,
                        fenceOffset.x,
                        fenceOffset.y - radiusPx - 15f,
                        textPaint
                    )
                }

                // 4. Draw Movement History Trails (Glowing dotted tracks)
                for (member in members) {
                    val rawPoints = member.historyPointsJson.split("|")
                    val pts = mutableListOf<Offset>()
                    for (p in rawPoints) {
                        val latlng = p.split(",")
                        if (latlng.size == 2) {
                            val lat = latlng[0].toDoubleOrNull() ?: continue
                            val lng = latlng[1].toDoubleOrNull() ?: continue
                            val rLat = (lat - 37.7600) * 12000f
                            val rLng = (lng - -122.4200) * 12000f
                            pts.add(Offset(rLng.toFloat(), -rLat.toFloat()))
                        }
                    }

                    if (pts.size > 1) {
                        val path = Path()
                        path.moveTo(pts[0].x, pts[0].y)
                        for (i in 1 until pts.size) {
                            path.lineTo(pts[i].x, pts[i].y)
                        }

                        // Select track color matching member's dynamic state
                        val trailColor = if (selectedMember?.id == member.id) {
                            PrimaryNeonCyan
                        } else {
                            PrimaryNeonCyan.copy(alpha = 0.35f)
                        }

                        drawPath(
                            path = path,
                            color = trailColor,
                            style = Stroke(
                                width = 4f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f),
                                cap = StrokeCap.Round
                            )
                        )
                    }
                }

                // 5. Draw Member Interactive Pins (Floating layered radar circles)
                for (member in members) {
                    val rLat = (member.latitude - 37.7600) * 12000f
                    val rLng = (member.longitude - -122.4200) * 12000f
                    val pinOffset = Offset(rLng.toFloat(), -rLat.toFloat())

                    val isSelected = selectedMember?.id == member.id
                    val outerGlowRadius = if (isSelected) 42f else 30f
                    val innerRadius = if (isSelected) 24f else 18f

                    val accentColor = when (member.id) {
                        "son_1" -> AlertCriticalRed // Hot danger target alert status
                        "mother_1" -> SecondaryActiveGreen
                        "daughter_1" -> PrimaryNeonCyan
                        else -> AccentMutedGold
                    }

                    // Render multiple glowing ripple layers for live effect
                    drawCircle(
                        color = accentColor.copy(alpha = 0.25f),
                        center = pinOffset,
                        radius = outerGlowRadius + 12f
                    )

                    drawCircle(
                        color = accentColor.copy(alpha = 0.45f),
                        center = pinOffset,
                        radius = outerGlowRadius
                    )

                    drawCircle(
                        color = ObsidianBg,
                        center = pinOffset,
                        radius = innerRadius + 4f
                    )

                    drawCircle(
                        color = accentColor,
                        center = pinOffset,
                        radius = innerRadius
                    )

                    // Draw Relationship Initials Letter Inside Avatar Ring
                    val letterPaint = android.graphics.Paint().apply {
                        color = 0xFF1C1B1F.toInt() // Obsidian / Sophisticated Dark Bg
                        textSize = if (isSelected) 28f else 22f
                        isAntiAlias = true
                        textAlign = android.graphics.Paint.Align.CENTER
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                    }
                    drawContext.canvas.nativeCanvas.drawText(
                        member.name.take(1),
                        pinOffset.x,
                        pinOffset.y + (if (isSelected) 10f else 8f),
                        letterPaint
                    )

                    // Display Speeds as sub-tags if moving
                    if (member.speedKmh > 1.0f) {
                        val subTextPaint = android.graphics.Paint().apply {
                            color = 0xFFFFFFFF.toInt()
                            textSize = 14f
                            isAntiAlias = true
                            textAlign = android.graphics.Paint.Align.CENTER
                        }
                        drawContext.canvas.nativeCanvas.drawText(
                            "${member.speedKmh.toInt()} km/h",
                            pinOffset.x,
                            pinOffset.y + outerGlowRadius + 22f,
                            subTextPaint
                        )
                    }
                }
            }
        }
    }
}
