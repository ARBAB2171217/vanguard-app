package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        MemberEntity::class,
        GeofenceEntity::class,
        AlertEntity::class,
        MessageEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class VanguardDatabase : RoomDatabase() {

    abstract fun vanguardDao(): VanguardDao

    companion object {
        @Volatile
        private var INSTANCE: VanguardDatabase? = null

        fun getDatabase(context: Context): VanguardDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VanguardDatabase::class.java,
                    "vanguard_safety_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
