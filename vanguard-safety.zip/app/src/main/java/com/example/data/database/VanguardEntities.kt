package com.example.data.database

import androidx.room.*

@Entity(tableName = "family_members")
data class MemberEntity(
    @PrimaryKey val id: String,
    val name: String,
    val relationship: String,
    val latitude: Double, // Current Position
    val longitude: Double,
    val batteryPercent: Int,
    val networkStrength: Int, // 1 to 5 scale
    val speedKmh: Float,
    val lastSeenTime: String,
    val statusMessage: String,
    val isCharging: Boolean = false,
    val historyPointsJson: String = "" // List of LatLng history points stored as string "lat,lng|lat,lng"
)

@Entity(tableName = "geofences")
data class GeofenceEntity(
    @PrimaryKey val id: String,
    val name: String,
    val zoneType: String, // "HOME", "SCHOOL", "WORK", "DANGER"
    val centerLat: Double,
    val centerLng: Double,
    val radiusMeters: Double,
    val isTriggered: Boolean = false
)

@Entity(tableName = "alerts")
data class AlertEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val timestamp: Long,
    val severity: String, // "INFO", "WARNING", "CRITICAL", "SOS"
    val isRead: Boolean = false
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val senderId: String,
    val senderName: String,
    val text: String,
    val timestamp: Long,
    val isMine: Boolean,
    val isMedia: Boolean = false
)
