package com.example.data.database

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlin.math.*

class VanguardRepository(private val dao: VanguardDao) {

    val allMembers: Flow<List<MemberEntity>> = dao.getAllMembersFlow()
    val allGeofences: Flow<List<GeofenceEntity>> = dao.getAllGeofencesFlow()
    val allAlerts: Flow<List<AlertEntity>> = dao.getAllAlertsFlow()
    val allMessages: Flow<List<MessageEntity>> = dao.getAllMessagesFlow()

    suspend fun insertMember(member: MemberEntity) = dao.insertMember(member)
    suspend fun insertMembers(members: List<MemberEntity>) = dao.insertMembers(members)
    suspend fun updateMember(member: MemberEntity) = dao.updateMember(member)

    suspend fun insertGeofence(geofence: GeofenceEntity) = dao.insertGeofence(geofence)
    suspend fun deleteGeofence(id: String) = dao.deleteGeofenceById(id)
    suspend fun updateGeofenceTrigger(id: String, state: Boolean) = dao.updateGeofenceTriggerState(id, state)

    suspend fun triggerSOSAlert(description: String) {
        val sos = AlertEntity(
            id = java.util.UUID.randomUUID().toString(),
            title = "CRITICAL SOS BROADCAST",
            description = description,
            timestamp = System.currentTimeMillis(),
            severity = "SOS",
            isRead = false
        )
        dao.insertAlert(sos)
    }

    suspend fun insertAlert(alert: AlertEntity) = dao.insertAlert(alert)
    suspend fun clearAlerts() = dao.clearAllAlerts()

    suspend fun insertMessage(message: MessageEntity) = dao.insertMessage(message)
    suspend fun clearMessages() = dao.clearAllMessages()

    // Seeds rich default family members and geofences for premier UX matching User Intent
    suspend fun seedInitialDataIfEmpty() {
        val currentMembers = dao.getAllMembersDirect()
        if (currentMembers.isEmpty()) {
            val sampleMembers = listOf(
                MemberEntity(
                    id = "mother_1",
                    name = "Sarah",
                    relationship = "Mother",
                    latitude = 37.7749, // Home focus coordinates
                    longitude = -122.4194,
                    batteryPercent = 94,
                    networkStrength = 5,
                    speedKmh = 0.0f,
                    lastSeenTime = "Just now",
                    statusMessage = "Safe at Home Circle",
                    isCharging = true,
                    historyPointsJson = "37.7745,-122.4190|37.7747,-122.4192|37.7749,-122.4194"
                ),
                MemberEntity(
                    id = "father_1",
                    name = "Michael",
                    relationship = "Father",
                    latitude = 37.7891,
                    longitude = -122.4014,
                    batteryPercent = 78,
                    networkStrength = 4,
                    speedKmh = 52.3f,
                    lastSeenTime = "2 mins ago",
                    statusMessage = "Driving to Financial District",
                    isCharging = false,
                    historyPointsJson = "37.7801,-122.4110|37.7845,-122.4060|37.7891,-122.4014"
                ),
                MemberEntity(
                    id = "daughter_1",
                    name = "Lily",
                    relationship = "Sister",
                    latitude = 37.7599,
                    longitude = -122.4368,
                    batteryPercent = 88,
                    networkStrength = 5,
                    speedKmh = 0.0f,
                    lastSeenTime = "Active now",
                    statusMessage = "Studying at Sunset College",
                    isCharging = false,
                    historyPointsJson = "37.7590,-122.4360|37.7595,-122.4364|37.7599,-122.4368"
                ),
                MemberEntity(
                    id = "son_1",
                    name = "Emily", // Teenager / Child
                    relationship = "Daughter",
                    latitude = 37.7420,
                    longitude = -122.4225,
                    batteryPercent = 32,
                    networkStrength = 3,
                    speedKmh = 3.6f,
                    lastSeenTime = "Active 1 min ago",
                    statusMessage = "Walking - Dynamic Risk Alert",
                    isCharging = false,
                    historyPointsJson = "37.7480,-122.4200|37.7450,-122.4215|37.7420,-122.4225"
                )
            )
            dao.insertMembers(sampleMembers)

            val sampleGeofences = listOf(
                GeofenceEntity(
                    id = "geo_home",
                    name = "Primary Home Guard",
                    zoneType = "HOME",
                    centerLat = 37.7749,
                    centerLng = -122.4194,
                    radiusMeters = 150.0,
                    isTriggered = true
                ),
                GeofenceEntity(
                    id = "geo_school",
                    name = "Sunset elementary campus",
                    zoneType = "SCHOOL",
                    centerLat = 37.7599,
                    centerLng = -122.4368,
                    radiusMeters = 200.0,
                    isTriggered = false
                ),
                GeofenceEntity(
                    id = "geo_risk",
                    name = "Low-Light Southern Corridor",
                    zoneType = "DANGER",
                    centerLat = 37.7350,
                    centerLng = -122.4150,
                    radiusMeters = 400.0,
                    isTriggered = false
                )
            )
            for (geo in sampleGeofences) {
                dao.insertGeofence(geo)
            }

            // Default warm safety alerts
            val initialAlerts = listOf(
                AlertEntity(
                    id = "alert_init_1",
                    title = "System Setup Complete",
                    description = "Secure 256-bit encrypted telemetry channel active. Real-time background sync operating at low power draw.",
                    timestamp = System.currentTimeMillis() - 7200000,
                    severity = "INFO",
                    isRead = true
                ),
                AlertEntity(
                    id = "alert_init_2",
                    title = "Safe Arrival: Lily",
                    description = "Lily safe at Sunset elementary campus geofenced area. Circle members notified.",
                    timestamp = System.currentTimeMillis() - 3600000,
                    severity = "INFO",
                    isRead = false
                )
            )
            for (alt in initialAlerts) {
                dao.insertAlert(alt)
            }

            // Empty chat logs
            val initialMessages = listOf(
                MessageEntity(
                    id = "msg_1",
                    senderId = "mother_1",
                    senderName = "Sarah",
                    text = "Did everyone arrive safe today?",
                    timestamp = System.currentTimeMillis() - 10000000,
                    isMine = false
                ),
                MessageEntity(
                    id = "msg_2",
                    senderId = "daughter_1",
                    senderName = "Lily",
                    text = "Yes mom, at high speed driving with dad earlier. In school now!",
                    timestamp = System.currentTimeMillis() - 8000000,
                    isMine = false
                ),
                MessageEntity(
                    id = "msg_3",
                    senderId = "me_1",
                    senderName = "You",
                    text = "Awesome, tracking works perfectly on our Vanguard App.",
                    timestamp = System.currentTimeMillis() - 5000000,
                    isMine = true
                )
            )
            for (msg in initialMessages) {
                dao.insertMessage(msg)
            }
        }
    }

    // Drifts coordinate locations slightly to inject active tracking movement visual effects
    suspend fun simulateLiveMovementUpdates() {
        val current = dao.getAllMembersDirect()
        for (member in current) {
            // Speed up Father's car, move him slightly north/east
            var newLat = member.latitude
            var newLng = member.longitude
            var newSpeed = member.speedKmh
            var newBattery = member.batteryPercent
            var status = member.statusMessage
            var isCharging = member.isCharging

            when (member.id) {
                "father_1" -> {
                    // Simulates rapid freeway travel
                    newLat += 0.0004 * (0.8 + (Math.random() - 0.5) * 0.4)
                    newLng += 0.0003 * (0.8 + (Math.random() - 0.5) * 0.4)
                    newSpeed = 50f + (Math.random() * 10f).toFloat()
                    newBattery = max(50, member.batteryPercent - 1)
                    status = "Driving on Highway I-80"
                }
                "son_1" -> {
                    // Simulates walking home
                    newLat += 0.00005 * (Math.random() - 0.4)
                    newLng -= 0.00010 * (0.9 + (Math.random() - 0.5) * 0.5)
                    newSpeed = 3.2f + (Math.random() * 0.8f).toFloat()
                    newBattery = max(10, member.batteryPercent - 1)
                    status = "Walking in Mission District"
                }
                "daughter_1" -> {
                    // Lily is static inside campus, just slight GPS jitter
                    newLat += (Math.random() - 0.5) * 0.00002
                    newLng += (Math.random() - 0.5) * 0.00002
                    newSpeed = 0f
                    status = "Studying - Sunset campus library"
                }
                "mother_1" -> {
                    // Mother is static at home, status matches
                    newLat += (Math.random() - 0.5) * 0.00001
                    newLng += (Math.random() - 0.5) * 0.00001
                    newSpeed = 0f
                    isCharging = true
                    newBattery = min(100, member.batteryPercent + 1)
                    status = "At Home - Charging device"
                }
            }

            // Append new historical track segments
            val segs = member.historyPointsJson.split("|").toMutableList()
            if (segs.size > 20) segs.removeAt(0)
            segs.add(String.format(java.util.Locale.US, "%.5f,%.5f", newLat, newLng))
            val newHist = segs.joinToString("|")

            val updated = member.copy(
                latitude = newLat,
                longitude = newLng,
                speedKmh = newSpeed,
                batteryPercent = newBattery,
                statusMessage = status,
                isCharging = isCharging,
                historyPointsJson = newHist,
                lastSeenTime = "Active now"
            )
            dao.updateMember(updated)

            // Auto calculate geofence entries/exits
            checkGeofenceBreachesForMember(updated)
        }
    }

    // Mathematical Haversine Distance computation to check geofence zones
    private suspend fun checkGeofenceBreachesForMember(member: MemberEntity) {
        val fences = dao.getAllGeofencesFlow().first()
        for (fence in fences) {
            val distance = calculateDistanceMeters(
                member.latitude, member.longitude,
                fence.centerLat, fence.centerLng
            )
            val inside = distance <= fence.radiusMeters

            // If entering/exiting, generate system alerts!
            if (inside && !fence.isTriggered) {
                dao.updateGeofenceTriggerState(fence.id, true)
                dao.insertAlert(
                    AlertEntity(
                        id = java.util.UUID.randomUUID().toString(),
                        title = "Zone Enter: ${member.name}",
                        description = "${member.name} (${member.relationship}) entered ${fence.name} safely.",
                        timestamp = System.currentTimeMillis(),
                        severity = if (fence.zoneType == "DANGER") "WARNING" else "INFO"
                    )
                )
            } else if (!inside && fence.isTriggered) {
                dao.updateGeofenceTriggerState(fence.id, false)
                dao.insertAlert(
                    AlertEntity(
                        id = java.util.UUID.randomUUID().toString(),
                        title = "Zone Exit: ${member.name}",
                        description = "${member.name} (${member.relationship}) has left ${fence.name}.",
                        timestamp = System.currentTimeMillis(),
                        severity = if (fence.zoneType == "DANGER") "WARNING" else "INFO"
                    )
                )
            }
        }
    }

    private fun calculateDistanceMeters(
        lat1: Double, lon1: Double,
        lat2: Double, lon2: Double
    ): Double {
        val r = 6371e3 // Meters
        val phi1 = lat1 * Math.PI / 180
        val phi2 = lat2 * Math.PI / 180
        val deltaPhi = (lat2 - lat1) * Math.PI / 180
        val deltaLambda = (lon2 - lon1) * Math.PI / 180

        val a = sin(deltaPhi / 2).pow(2) +
                cos(phi1) * cos(phi2) * sin(deltaLambda / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))

        return r * c
    }
}
