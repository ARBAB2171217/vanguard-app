# Vanguard Family Safety Platform: Global DevOps & DevSecOps Blueprint
## Continuous Deployment, Scaling & Orchestration Spec

This manifest compiles and presents production deployment configurations for automated continuous delivery, containerization, and orchestration across Amazon Web Services (AWS) and Google Cloud Platform (GCP).

---

## 1. High-Performance Location Ingress - `Dockerfile`
High-speed container with multi-stage Go builder, compiling down to a single scratch image for minimal deployment memory print (~12MB total image size).

```dockerfile
# STEP 1: Build high-performance Go binaries
FROM golang:1.21-alpine AS builder

WORKDIR /app

RUN apk add --no-cache git ca-certificates

COPY go.mod go.sum ./
RUN go mod download

COPY . .

# Compile binary static links without debugging symbols
RUN CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -ldflags="-w -s" -o/bin/location-ingress ./cmd/ingress

# STEP 2: Create lightweight production container
FROM scratch

COPY --from=builder /etc/ssl/certs/ca-certificates.crt /etc/ssl/certs/
COPY --from=builder /bin/location-ingress /location-ingress

USER 65534:65534

EXPOSE 8080 9000

ENTRYPOINT ["/location-ingress"]
```

---

## 2. DevSecOps Multi-Container Local Orchestrator - `docker-compose.yml`
Leveraged by DevOps squads to replicate planetary clusters in sandbox configurations.

```yaml
version: '3.8'

services:
  ingress-gateway:
    build:
      context: ./services/ingress
      dockerfile: Dockerfile
    ports:
      - "8080:8080"
      - "9000:9000"
    environment:
      - PORT=8080
      - REDIS_PUB_URL=redis://redis:6379/0
      - KAFKA_HOSTS=kafka:29092
      - POSTGRES_DSN=postgres://vanguard_app:VanguardSuperSecure2026@timescaledb:5432/vanguard_db
    depends_on:
      - timescaledb
      - redis
      - kafka

  redis:
    image: redis:7.0-alpine
    command: redis-server --appendonly yes --requirepass VanguardSuperRedis2026
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data

  timescaledb:
    image: timescale/timescaledb:latest-pg15
    ports:
      - "5432:5432"
    environment:
      - POSTGRES_DB=vanguard_db
      - POSTGRES_USER=vanguard_app
      - POSTGRES_PASSWORD=VanguardSuperSecure2026
    volumes:
      - timescale-data:/var/lib/postgresql/data

  mongodb:
    image: mongo:6.0
    ports:
      - "27017:27017"
    environment:
      - MONGO_INITDB_ROOT_USERNAME=admin
      - MONGO_INITDB_ROOT_PASSWORD=VanguardMongoSecure2026
    volumes:
      - mongo-data:/data/db

  kafka:
    image: confluentinc/cp-kafka:7.3.0
    ports:
      - "9092:9092"
    environment:
      - KAFKA_ZOOKEEPER_CONNECT=zookeeper:2181
      - KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://kafka:29092,PLAINTEXT_HOST://localhost:9092
      - KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR=1
    depends_on:
      - zookeeper

  zookeeper:
    image: confluentinc/cp-zookeeper:7.3.0
    environment:
      - ZOOKEEPER_CLIENT_PORT=2181

volumes:
  timescale-data:
  redis-data:
  mongo-data:
```

---

## 3. High-Scale Kubernetes Ingress & Auto-Scaling Manifest - `kubernetes.yaml`
Provides active auto-scaling arrays when client traffic swings across regions.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: location-ingress-deployment
  namespace: vanguard-production
  labels:
    app: location-ingress
spec:
  replicas: 10
  selector:
    matchLabels:
      app: location-ingress
  template:
    metadata:
      labels:
        app: location-ingress
    spec:
      containers:
      - name: location-ingress-pod
        image: 316146706361.dkr.ecr.us-east-1.amazonaws.com/vanguard/location-ingress:v1.0.0
        ports:
        - containerPort: 8080
        resources:
          limits:
            cpu: "1"
            memory: 1024Mi
          requests:
            cpu: "250m"
            memory: 256Mi
        livenessProbe:
          httpGet:
            path: /healthz
            port: 8080
          initialDelaySeconds: 10
          periodSeconds: 5
        readinessProbe:
          httpGet:
            path: /ready
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: location-ingress-hpa
  namespace: vanguard-production
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: location-ingress-deployment
  minReplicas: 5
  maxReplicas: 150
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 75
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

---

## 4. GitHub Actions Canary Deployment CI/CD - `canary-deploy.yml`
Ensures that new code has been automatically vetted, unit tested, and canary-deployed before rollout.

```yaml
name: Vanguard Continuous Integration / Deployment

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  validate-and-test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3

    - name: Set up Go
      uses: actions/setup-go@v4
      with:
        go-version: '1.21'

    - name: Run Unit Tests
      run: |
        go test -v -race -covermode=atomic ./...

  build-and-deploy:
    needs: validate-and-test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3

    - name: Configure AWS Credentials
      uses: aws-actions/configure-aws-credentials@v2
      with:
        aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
        aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        aws-region: us-east-1

    - name: Login to Amazon ECR
      id: login-ecr
      uses: aws-actions/amazon-ecr-login@v1

    - name: Build and Push Docker container
      run: |
        docker build -t ${{ steps.login-ecr.outputs.registry }}/vanguard-ingress:${{ github.sha }} .
        docker push ${{ steps.login-ecr.outputs.registry }}/vanguard-ingress:${{ github.sha }}

    - name: Execute Canary Rollout (Kustomize / Helm)
      run: |
        aws eks update-kubeconfig --name vanguard-prod-eks --region us-east-1
        kubectl set image deployment/location-ingress-deployment location-ingress-pod=${{ steps.login-ecr.outputs.registry }}/vanguard-ingress:${{ github.sha }} -n vanguard-production
        # Auto audits canary errors and triggers rollback if container crashes
        kubectl rollout status deployment/location-ingress-deployment -n vanguard-production
```
