# Vanguard Family Safety Platform: Enterprise Systems Architecture & Spec
## Production-Grade Multi-Region Global Infrastructure

This document outlines the planetary-scale, military-grade architecture, database designs, real-time message streaming flow, and compliance blueprints for the Vanguard Family Safety & Live Tracking Platform.

---

## 1. System Architecture Diagram

```
[Android Client]      [iOS Client]      [Smartwatches (WearOS/WatchOS)]  [Autos (CarPlay/AA)]
       │                   │                           │                         │
       └───────────────────┴─────────────┬─────────────┴─────────────────────────┘
                                         │
                        [Cloudflare Enterprise Edge: TLS 1.3]
                                         │  (DDoS Shield, WAF Routing)
                                         ▼
                             [AWS API Gateway / ALB]
                                         │
        ┌────────────────────────────────┴────────────────────────────────┐
        ▼ (REST / gRPC Streams)                                           ▼ (WebSockets / HTTP)
  [Edge DNS / Ingress]                                              [Real-time PubSub]
        │                                                                 │
        ├──► Auth & IAM Service (Node.js/Go) ──► Redis (JWT Session)      ├──► WS Connection Manager (Go)
        │                                                                 │     │
        ├──► Circle Mgmt Service                                          │     ▼
        │                                                                 │   [Redis PubSub Ring]
        ├──► Geofence Engine Ingestion ───────────────────────────────────┤     │
        │                                                                 │     ▼
        ├──► SOS Emergency Processor ──────────────────────────────────────┼──► Kafka Location Stream
        │                                                                 │     │
        └──► Guardia AI Analytics (Gemini) ◄─── MongoDB (Event Log)       │     ▼
                                                                          │  [TimescaleDB Ingestion]
                                                                          │  (Partitioned GPS coordinates)
                                                                          ▼
                                                                    [PostgreSQL RDS]
                                                                 (Relational Circle DBs)
```

---

## 2. Microservices Architecture & Global Orchestration

Vanguard uses a highly decoupled **SaaS Microservices Architecture** written in Go and Node.js.

### Core Services:
*   **Location Ingress Gateway (Go):** High-performance, low-memory UDP/TCP/WS endpoint that ingests high-frequency telemetry tracking packets from active devices using Google Protocol Buffers (Protobuf).
*   **Geofencing & Circle Engine (Go):** Sub-10ms evaluation service that matches live GPS coordinate updates against active polygon/circle boundaries using custom R-Tree spatial indexing.
*   **Guardia AI Copilot Service (Node.js + TS):** Uses Gemini to detect malicious or anomalous safety patterns, calculate risk profiles, generate spatial heuristics, and trigger preventive recommendations.
*   **Emergency Emergency Chain (Go):** Highest-priority event broker. On SOS trigger, instantly initializes WebRTC video streams, triggers SMS fallback aggregators (Twilio), emails, and secure VoIP escalations to local emergency response agencies (911/112).
*   **Sub & Billing Engine (Node.js + Stripe/Razorpay):** Manages multi-tier SaaS invoicing, token rotation, and in-app purchase receipts.

---

## 3. Database Schema Blueprint (DaaS Layer)

### A. TimescaleDB Schema (Location & Telemetry Logs)
Optimized for high-throughput write and hyper-efficient historical query performance over millions of active circles.

```sql
-- Hypertable containing millions of rows of location points
CREATE TABLE family_location_logs (
    id UUID NOT NULL DEFAULT gen_random_uuid(),
    member_id UUID NOT NULL,
    circle_id UUID NOT NULL,
    recorded_at TIMESTAMPTZ NOT NULL,
    coordinate GEOMETRY(Point, 4326) NOT NULL,
    altitude DOUBLE PRECISION,
    speed_kmh REAL NOT NULL,
    bearing REAL,
    battery_percentage INT NOT NULL,
    network_strength INT NOT NULL, -- Decibel score (dBm) or 0-5 index
    is_charging BOOLEAN DEFAULT FALSE,
    device_state JSONB, -- { "screen_on": true, "spoof_detected": false }
    PRIMARY KEY (member_id, recorded_at)
);

-- Convert standard table into a TimescaleDB hypertable partitioned by recorded_at
SELECT create_hypertable('family_location_logs', 'recorded_at', chunk_time_interval => INTERVAL '1 day');

-- Setup compression policies (save 90% disk space)
ALTER TABLE family_location_logs SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'member_id, circle_id'
);
SELECT add_compression_policy('family_location_logs', INTERVAL '7 days');
```

### B. PostgreSQL Relational Schema (User & Safety Group Domain)
Stores strict referential data for users, circle groups, geofences, and subscriptions.

```sql
-- Security Schema
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone_number VARCHAR(32) NOT NULL,
    full_name VARCHAR(128) NOT NULL,
    avatar_url VARCHAR(512),
    mfa_secret VARCHAR(128),
    role VARCHAR(32) DEFAULT 'member', -- admin, moderator, owner, member
    is_two_factor_enabled BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE family_circles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(128) NOT NULL,
    invite_code VARCHAR(8) UNIQUE NOT NULL,
    owner_id UUID REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE circle_memberships (
    circle_id UUID REFERENCES family_circles(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    joined_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    is_admin BOOLEAN DEFAULT FALSE,
    PRIMARY KEY (circle_id, user_id)
);

-- Geofences (Polygon and Circular Bounds)
CREATE TABLE geofences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    circle_id UUID REFERENCES family_circles(id) ON DELETE CASCADE,
    name VARCHAR(128) NOT NULL,
    boundary_type VARCHAR(16) CHECK (boundary_type IN ('RADIUS', 'POLYGON')),
    center_latitude DOUBLE PRECISION NOT NULL,
    center_longitude DOUBLE PRECISION NOT NULL,
    radius_meters DOUBLE PRECISION, -- Nullable for Polygons
    polygon_vertices JSONB, -- Coordinates array of vertex coordinates [[[lon, lat], ...]]
    zone_classification VARCHAR(16) CHECK (zone_classification IN ('SAFE', 'NEUTRAL', 'RISKY', 'CRITICAL')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Subscription Invoices
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    stripe_subscription_id VARCHAR(255) UNIQUE,
    plan_tier VARCHAR(32) NOT NULL, -- 'FREE', 'PREMIUM_FAMILY', 'VANGUARD_FLEET'
    status VARCHAR(32) NOT NULL, -- 'active', 'canceled', 'past_due'
    current_period_end TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
```

### C. MongoDB Schema (Security Auditing & Alerts Log)
Used to keep high-speed timeline events, crash statistics, and behavioral alert archives.

```json
{
  "_id": "64bc1dfaee...",
  "circleId": "e1a90c88-...",
  "type": "GEOFENCE_BREACH",
  "severity": "WARNING",
  "senderId": "778ac921-...",
  "details": {
    "memberName": "Emily Smith",
    "geofenceId": "34900da-..",
    "geofenceName": "Sunset Elementary School",
    "direction": "EXIT",
    "timestamp": "2026-06-05T18:30:11Z",
    "speed": 18.4,
    "batteryLevel": 88
  },
  "guardia_ai_analysis": {
    "irregularity_score": 0.12,
    "context": "Normal dismissal hours. Route analysis matches usual walking pattern."
  },
  "read_receipts": [
    { "userId": "893caca-...", "readAt": "2026-06-05T18:31:00Z" }
  ]
}
```

---

## 4. API Endpoints Speeds & WebSockets Specifications (OpenAPI Style)

All REST / gRPC services require JSON Web Tokens (`Authorization: Bearer <JWT>`) with short-lived access duration and automated refresh rotation.

### A. Location Update (Ingress Stream - Protobuf)
```protobuf
syntax = "proto3";
package vanguard.location;

message LocationTelemetry {
  string member_id = 1;
  string circle_id = 2;
  double latitude = 3;
  double longitude = 4;
  float speed_kmh = 5;
  int32 battery_percentage = 6;
  int64 timestamp_ms = 7;
  bool is_mock_gps = 8;
  string token = 9;
}
```

### B. Real-time REST Endpoints
*   `POST /api/v1/auth/signup` - Registers users, establishes security fingerprints.
*   `POST /api/v1/circle/create` - Instantiates family safety perimeter ring.
*   `POST /api/v1/geofence/add` - Deploys spatial boundary trigger.
*   `GET /api/v1/history/timeline?member_id={id}&date={ISO}` - Pulls high-speed location trail segments.
*   `POST /api/v1/sos/trigger` - Commands massive instant distress alarm and live system broadcasting.

---

## 5. Security & Legal Standard Verification

Our platform stands out via its rigid adherence to strict security parameters:
1.  **Differential Privacy (Fuzzy Mode):** Optional "Ghost Mode" introduces Laplace-distributed visual noise on GPS feeds for selected times to respect tracking consent.
2.  **Anti-Spoof Engine:** On-device Kotlin code parses `Location.isFromMockProvider()` status, checks and matches cellular network triangulation against GPS drift, alerting admins if telemetry is spoofed.
3.  **Encrypted Vaulting:** End-to-end user communications are layered with **X3DH / Double Ratchet Protocol** for tamper-free safety chats.
4.  **Compliance Protocol (GDPR & CCPA):** Instant single-click total data expunging pipelines run across TimescaleDB, MongoDB, and local caches for legal compliance.
